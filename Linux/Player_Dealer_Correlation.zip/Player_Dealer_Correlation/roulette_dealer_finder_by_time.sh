#!/bin/bash

# This script is used to print out specified columns in a line of text based on the search query

# This line tells the user to enter date and time for processing
echo Please enter the date and time : 

# This line reads the time from the standard input, the format is  05:00:00 AM
read varQuery

# This line tells the user to enter the file path
echo Please enter the absolute path of the file for processing :

# This line reads the absolute location of the file from standard input
read varPath


# This command uses the passed argument to write a line based on the parameter and pipes into awk that prints the content of each column
grep -i "$varQuery"  $varPath | awk -F ' ' '{print $1, $2, $5, $6}' 
