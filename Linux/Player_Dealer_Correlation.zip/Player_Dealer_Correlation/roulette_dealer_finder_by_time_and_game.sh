#!/bin/bash

# This line tells the user to enter date and time for processing
echo Please enter the date and time:

# This line reads the time from the standard input
read varTime

# This line tells the user to enter the Casino game name
echo Please enter the Casino game name

# This line reads the name of the Casino game played
read varName

# This line displays the prameter used to search
echo  The parameter used for this searched is $varTime $varName 

# This line sets the input query parameter into a variable varQuery
echo $varTime $varName > varQuery

# This line tells the user to enter the absolute file path
echo Please enter the absolute path of the file for processing:

# This line reads the absolute location of the file from standard input
read varPath

# This command uses the passed argument to write a line based on the parameter and pipes into awk that prints the content of each column
grep -i "$varQuery" $varPath | awk -F ' ' '{print $1, $2, $5, $6}'

